# node-chat-app
A real time audio, video and text based chating application using Node.js and Socket.IO

## Demo
<img src="/Node%20Chat%20App.gif?raw=true" width="800px">
